from colorama import Fore, Back, Style
def main():
    print(Fore.RED + "Xin Chao!")


if __name__ == '__main__':
    main()
